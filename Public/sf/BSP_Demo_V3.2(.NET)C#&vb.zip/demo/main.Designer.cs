﻿namespace demo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtb_remark = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtb_order_source = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.dtp_sendstarttime = new System.Windows.Forms.DateTimePicker();
            this.comb_pay_method = new System.Windows.Forms.ComboBox();
            this.comb_express_type = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtb_cargo_total_weight = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtb_custid = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtb_parcel_quantity = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtb_orderid = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.txtb_source_area = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtb_currency = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtb_amount = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtb_weight = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtb_unit = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txtb_count = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtb_CargoName = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtb_j_address = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtb_j_county = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtb_j_city = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtb_j_province = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtb_j_mobile = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtb_j_tel = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtb_j_contact = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtb_j_company = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.txtb_d_address = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtb_d_county = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtb_d_city = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtb_d_province = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtb_d_mobile = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtb_d_tel = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtb_d_contact = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtb_d_company = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.txtb_INSURE_value = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.txtb_cod_value = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.txtb_cod_custid = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.checkB_COD = new System.Windows.Forms.CheckBox();
            this.checkB_INSURE = new System.Windows.Forms.CheckBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtB_Checkword = new System.Windows.Forms.TextBox();
            this.txtB_JRM = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tXTB_Request = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtb_back = new System.Windows.Forms.TextBox();
            this.lab_log = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label45 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1, 474);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 37);
            this.button1.TabIndex = 0;
            this.button1.Text = "下单";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(1, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(513, 436);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label47);
            this.tabPage1.Controls.Add(this.label45);
            this.tabPage1.Controls.Add(this.txtb_remark);
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.txtb_order_source);
            this.tabPage1.Controls.Add(this.label30);
            this.tabPage1.Controls.Add(this.dtp_sendstarttime);
            this.tabPage1.Controls.Add(this.comb_pay_method);
            this.tabPage1.Controls.Add(this.comb_express_type);
            this.tabPage1.Controls.Add(this.label29);
            this.tabPage1.Controls.Add(this.txtb_cargo_total_weight);
            this.tabPage1.Controls.Add(this.label28);
            this.tabPage1.Controls.Add(this.txtb_custid);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.txtb_parcel_quantity);
            this.tabPage1.Controls.Add(this.label25);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.txtb_orderid);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(505, 410);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "订单信息";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtb_remark
            // 
            this.txtb_remark.Location = new System.Drawing.Point(77, 231);
            this.txtb_remark.Multiline = true;
            this.txtb_remark.Name = "txtb_remark";
            this.txtb_remark.Size = new System.Drawing.Size(183, 117);
            this.txtb_remark.TabIndex = 25;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(6, 234);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(65, 12);
            this.label31.TabIndex = 24;
            this.label31.Text = "备注信息：";
            // 
            // txtb_order_source
            // 
            this.txtb_order_source.Location = new System.Drawing.Point(77, 205);
            this.txtb_order_source.Name = "txtb_order_source";
            this.txtb_order_source.Size = new System.Drawing.Size(183, 21);
            this.txtb_order_source.TabIndex = 23;
            this.txtb_order_source.Text = "西门府";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(7, 208);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 12);
            this.label30.TabIndex = 22;
            this.label30.Text = "订单来源：";
            // 
            // dtp_sendstarttime
            // 
            this.dtp_sendstarttime.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dtp_sendstarttime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_sendstarttime.Location = new System.Drawing.Point(77, 178);
            this.dtp_sendstarttime.Name = "dtp_sendstarttime";
            this.dtp_sendstarttime.ShowUpDown = true;
            this.dtp_sendstarttime.Size = new System.Drawing.Size(183, 21);
            this.dtp_sendstarttime.TabIndex = 21;
            // 
            // comb_pay_method
            // 
            this.comb_pay_method.FormattingEnabled = true;
            this.comb_pay_method.Location = new System.Drawing.Point(77, 95);
            this.comb_pay_method.Name = "comb_pay_method";
            this.comb_pay_method.Size = new System.Drawing.Size(183, 20);
            this.comb_pay_method.TabIndex = 20;
            this.comb_pay_method.Text = "--选择付款方式--";
            this.comb_pay_method.SelectedIndexChanged += new System.EventHandler(this.comb_pay_method_SelectedIndexChanged);
            // 
            // comb_express_type
            // 
            this.comb_express_type.FormattingEnabled = true;
            this.comb_express_type.Location = new System.Drawing.Point(77, 40);
            this.comb_express_type.Name = "comb_express_type";
            this.comb_express_type.Size = new System.Drawing.Size(183, 20);
            this.comb_express_type.TabIndex = 19;
            this.comb_express_type.Text = "--选择业务类型--";
            this.comb_express_type.SelectedIndexChanged += new System.EventHandler(this.comb_express_type_SelectedIndexChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(7, 184);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 12);
            this.label29.TabIndex = 17;
            this.label29.Text = "发货时间：";
            // 
            // txtb_cargo_total_weight
            // 
            this.txtb_cargo_total_weight.Location = new System.Drawing.Point(77, 148);
            this.txtb_cargo_total_weight.Name = "txtb_cargo_total_weight";
            this.txtb_cargo_total_weight.Size = new System.Drawing.Size(183, 21);
            this.txtb_cargo_total_weight.TabIndex = 16;
            this.txtb_cargo_total_weight.Text = "2.35";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(7, 151);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(65, 12);
            this.label28.TabIndex = 15;
            this.label28.Text = "快件总量：";
            // 
            // txtb_custid
            // 
            this.txtb_custid.Location = new System.Drawing.Point(77, 121);
            this.txtb_custid.Name = "txtb_custid";
            this.txtb_custid.Size = new System.Drawing.Size(183, 21);
            this.txtb_custid.TabIndex = 14;
            this.txtb_custid.Text = "7551878519";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(7, 124);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(65, 12);
            this.label27.TabIndex = 13;
            this.label27.Text = "月结卡号：";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 97);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(65, 12);
            this.label26.TabIndex = 11;
            this.label26.Text = "付款方式：";
            // 
            // txtb_parcel_quantity
            // 
            this.txtb_parcel_quantity.Location = new System.Drawing.Point(77, 67);
            this.txtb_parcel_quantity.Name = "txtb_parcel_quantity";
            this.txtb_parcel_quantity.Size = new System.Drawing.Size(183, 21);
            this.txtb_parcel_quantity.TabIndex = 10;
            this.txtb_parcel_quantity.Text = "1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(18, 70);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 12);
            this.label25.TabIndex = 9;
            this.label25.Text = "包裹数：";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(7, 43);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 12);
            this.label24.TabIndex = 7;
            this.label24.Text = "业务类型：";
            // 
            // txtb_orderid
            // 
            this.txtb_orderid.Location = new System.Drawing.Point(77, 13);
            this.txtb_orderid.Name = "txtb_orderid";
            this.txtb_orderid.Size = new System.Drawing.Size(183, 21);
            this.txtb_orderid.TabIndex = 6;
            this.txtb_orderid.Text = "XJFS_07110098";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(18, 16);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 5;
            this.label23.Text = "订单号：";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.label54);
            this.tabPage7.Controls.Add(this.txtb_source_area);
            this.tabPage7.Controls.Add(this.label38);
            this.tabPage7.Controls.Add(this.txtb_currency);
            this.tabPage7.Controls.Add(this.label35);
            this.tabPage7.Controls.Add(this.txtb_amount);
            this.tabPage7.Controls.Add(this.label36);
            this.tabPage7.Controls.Add(this.txtb_weight);
            this.tabPage7.Controls.Add(this.label37);
            this.tabPage7.Controls.Add(this.txtb_unit);
            this.tabPage7.Controls.Add(this.label34);
            this.tabPage7.Controls.Add(this.txtb_count);
            this.tabPage7.Controls.Add(this.label33);
            this.tabPage7.Controls.Add(this.txtb_CargoName);
            this.tabPage7.Controls.Add(this.label32);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(505, 410);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "商品信息";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // txtb_source_area
            // 
            this.txtb_source_area.Location = new System.Drawing.Point(77, 187);
            this.txtb_source_area.Name = "txtb_source_area";
            this.txtb_source_area.Size = new System.Drawing.Size(183, 21);
            this.txtb_source_area.TabIndex = 20;
            this.txtb_source_area.Text = "中国";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(4, 190);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(77, 12);
            this.label38.TabIndex = 19;
            this.label38.Text = "原产地国别：";
            // 
            // txtb_currency
            // 
            this.txtb_currency.Location = new System.Drawing.Point(77, 160);
            this.txtb_currency.Name = "txtb_currency";
            this.txtb_currency.Size = new System.Drawing.Size(183, 21);
            this.txtb_currency.TabIndex = 18;
            this.txtb_currency.Text = "CNY";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(16, 163);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(65, 12);
            this.label35.TabIndex = 17;
            this.label35.Text = "结算货币：";
            // 
            // txtb_amount
            // 
            this.txtb_amount.Location = new System.Drawing.Point(77, 133);
            this.txtb_amount.Name = "txtb_amount";
            this.txtb_amount.Size = new System.Drawing.Size(183, 21);
            this.txtb_amount.TabIndex = 16;
            this.txtb_amount.Text = "100";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(16, 136);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(65, 12);
            this.label36.TabIndex = 15;
            this.label36.Text = "商品单价：";
            // 
            // txtb_weight
            // 
            this.txtb_weight.Location = new System.Drawing.Point(77, 103);
            this.txtb_weight.Name = "txtb_weight";
            this.txtb_weight.Size = new System.Drawing.Size(183, 21);
            this.txtb_weight.TabIndex = 14;
            this.txtb_weight.Text = "0.02";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(16, 106);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 12);
            this.label37.TabIndex = 13;
            this.label37.Text = "商品单重：";
            // 
            // txtb_unit
            // 
            this.txtb_unit.Location = new System.Drawing.Point(77, 76);
            this.txtb_unit.Name = "txtb_unit";
            this.txtb_unit.Size = new System.Drawing.Size(183, 21);
            this.txtb_unit.TabIndex = 12;
            this.txtb_unit.Text = "台";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(16, 79);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(65, 12);
            this.label34.TabIndex = 11;
            this.label34.Text = "商品单位：";
            // 
            // txtb_count
            // 
            this.txtb_count.Location = new System.Drawing.Point(77, 49);
            this.txtb_count.Name = "txtb_count";
            this.txtb_count.Size = new System.Drawing.Size(183, 21);
            this.txtb_count.TabIndex = 10;
            this.txtb_count.Text = "2";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(16, 52);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(65, 12);
            this.label33.TabIndex = 9;
            this.label33.Text = "商品数量：";
            // 
            // txtb_CargoName
            // 
            this.txtb_CargoName.Location = new System.Drawing.Point(77, 19);
            this.txtb_CargoName.Name = "txtb_CargoName";
            this.txtb_CargoName.Size = new System.Drawing.Size(183, 21);
            this.txtb_CargoName.TabIndex = 8;
            this.txtb_CargoName.Text = "扇子";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(16, 22);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(65, 12);
            this.label32.TabIndex = 7;
            this.label32.Text = "商品名称：";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label50);
            this.tabPage2.Controls.Add(this.label49);
            this.tabPage2.Controls.Add(this.txtb_j_address);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.txtb_j_county);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.txtb_j_city);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.txtb_j_province);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.txtb_j_mobile);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.txtb_j_tel);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtb_j_contact);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.txtb_j_company);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(505, 410);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "收件信息";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // txtb_j_address
            // 
            this.txtb_j_address.Location = new System.Drawing.Point(90, 201);
            this.txtb_j_address.Multiline = true;
            this.txtb_j_address.Name = "txtb_j_address";
            this.txtb_j_address.Size = new System.Drawing.Size(183, 99);
            this.txtb_j_address.TabIndex = 16;
            this.txtb_j_address.Text = "北京市朝阳区科学园科健路338号";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 204);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 12);
            this.label13.TabIndex = 15;
            this.label13.Text = "详细地址：";
            // 
            // txtb_j_county
            // 
            this.txtb_j_county.Location = new System.Drawing.Point(90, 174);
            this.txtb_j_county.Name = "txtb_j_county";
            this.txtb_j_county.Size = new System.Drawing.Size(183, 21);
            this.txtb_j_county.TabIndex = 14;
            this.txtb_j_county.Text = "朝阳区";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(37, 177);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 12);
            this.label12.TabIndex = 13;
            this.label12.Text = "区/县：";
            // 
            // txtb_j_city
            // 
            this.txtb_j_city.Location = new System.Drawing.Point(90, 147);
            this.txtb_j_city.Name = "txtb_j_city";
            this.txtb_j_city.Size = new System.Drawing.Size(183, 21);
            this.txtb_j_city.TabIndex = 12;
            this.txtb_j_city.Text = "北京";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(55, 150);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 11;
            this.label11.Text = "市：";
            // 
            // txtb_j_province
            // 
            this.txtb_j_province.Location = new System.Drawing.Point(90, 120);
            this.txtb_j_province.Name = "txtb_j_province";
            this.txtb_j_province.Size = new System.Drawing.Size(183, 21);
            this.txtb_j_province.TabIndex = 10;
            this.txtb_j_province.Text = "北京";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(55, 123);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 9;
            this.label10.Text = "省：";
            // 
            // txtb_j_mobile
            // 
            this.txtb_j_mobile.Location = new System.Drawing.Point(90, 93);
            this.txtb_j_mobile.Name = "txtb_j_mobile";
            this.txtb_j_mobile.Size = new System.Drawing.Size(183, 21);
            this.txtb_j_mobile.TabIndex = 8;
            this.txtb_j_mobile.Text = "13800138000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(43, 96);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 7;
            this.label9.Text = "手机：";
            // 
            // txtb_j_tel
            // 
            this.txtb_j_tel.Location = new System.Drawing.Point(90, 66);
            this.txtb_j_tel.Name = "txtb_j_tel";
            this.txtb_j_tel.Size = new System.Drawing.Size(183, 21);
            this.txtb_j_tel.TabIndex = 6;
            this.txtb_j_tel.Text = "010-1111112";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(43, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 5;
            this.label8.Text = "电话：";
            // 
            // txtb_j_contact
            // 
            this.txtb_j_contact.Location = new System.Drawing.Point(90, 39);
            this.txtb_j_contact.Name = "txtb_j_contact";
            this.txtb_j_contact.Size = new System.Drawing.Size(183, 21);
            this.txtb_j_contact.TabIndex = 4;
            this.txtb_j_contact.Text = "客服4号";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(31, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 3;
            this.label7.Text = "联系人：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(278, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(12, 12);
            this.label6.TabIndex = 2;
            this.label6.Text = "*";
            // 
            // txtb_j_company
            // 
            this.txtb_j_company.Location = new System.Drawing.Point(90, 12);
            this.txtb_j_company.Name = "txtb_j_company";
            this.txtb_j_company.Size = new System.Drawing.Size(183, 21);
            this.txtb_j_company.TabIndex = 1;
            this.txtb_j_company.Text = "华为";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "寄件公司：";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.label53);
            this.tabPage6.Controls.Add(this.label52);
            this.tabPage6.Controls.Add(this.label51);
            this.tabPage6.Controls.Add(this.txtb_d_address);
            this.tabPage6.Controls.Add(this.label14);
            this.tabPage6.Controls.Add(this.txtb_d_county);
            this.tabPage6.Controls.Add(this.label15);
            this.tabPage6.Controls.Add(this.txtb_d_city);
            this.tabPage6.Controls.Add(this.label16);
            this.tabPage6.Controls.Add(this.txtb_d_province);
            this.tabPage6.Controls.Add(this.label17);
            this.tabPage6.Controls.Add(this.txtb_d_mobile);
            this.tabPage6.Controls.Add(this.label18);
            this.tabPage6.Controls.Add(this.txtb_d_tel);
            this.tabPage6.Controls.Add(this.label19);
            this.tabPage6.Controls.Add(this.txtb_d_contact);
            this.tabPage6.Controls.Add(this.label20);
            this.tabPage6.Controls.Add(this.label21);
            this.tabPage6.Controls.Add(this.txtb_d_company);
            this.tabPage6.Controls.Add(this.label22);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(505, 410);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "派件信息";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // txtb_d_address
            // 
            this.txtb_d_address.Location = new System.Drawing.Point(101, 203);
            this.txtb_d_address.Multiline = true;
            this.txtb_d_address.Name = "txtb_d_address";
            this.txtb_d_address.Size = new System.Drawing.Size(183, 99);
            this.txtb_d_address.TabIndex = 33;
            this.txtb_d_address.Text = "广东省深圳市福田区新洲十一街万基商务大厦10楼";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(30, 206);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 32;
            this.label14.Text = "详细地址：";
            // 
            // txtb_d_county
            // 
            this.txtb_d_county.Location = new System.Drawing.Point(101, 176);
            this.txtb_d_county.Name = "txtb_d_county";
            this.txtb_d_county.Size = new System.Drawing.Size(183, 21);
            this.txtb_d_county.TabIndex = 31;
            this.txtb_d_county.Text = "福田区";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(48, 179);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 12);
            this.label15.TabIndex = 30;
            this.label15.Text = "区/县：";
            // 
            // txtb_d_city
            // 
            this.txtb_d_city.Location = new System.Drawing.Point(101, 149);
            this.txtb_d_city.Name = "txtb_d_city";
            this.txtb_d_city.Size = new System.Drawing.Size(183, 21);
            this.txtb_d_city.TabIndex = 29;
            this.txtb_d_city.Text = "深圳市";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(66, 152);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 28;
            this.label16.Text = "市：";
            // 
            // txtb_d_province
            // 
            this.txtb_d_province.Location = new System.Drawing.Point(101, 122);
            this.txtb_d_province.Name = "txtb_d_province";
            this.txtb_d_province.Size = new System.Drawing.Size(183, 21);
            this.txtb_d_province.TabIndex = 27;
            this.txtb_d_province.Text = "广东省";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(66, 125);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 26;
            this.label17.Text = "省：";
            // 
            // txtb_d_mobile
            // 
            this.txtb_d_mobile.Location = new System.Drawing.Point(101, 95);
            this.txtb_d_mobile.Name = "txtb_d_mobile";
            this.txtb_d_mobile.Size = new System.Drawing.Size(183, 21);
            this.txtb_d_mobile.TabIndex = 25;
            this.txtb_d_mobile.Text = "17002930913";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(54, 98);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 12);
            this.label18.TabIndex = 24;
            this.label18.Text = "手机：";
            // 
            // txtb_d_tel
            // 
            this.txtb_d_tel.Location = new System.Drawing.Point(101, 68);
            this.txtb_d_tel.Name = "txtb_d_tel";
            this.txtb_d_tel.Size = new System.Drawing.Size(183, 21);
            this.txtb_d_tel.TabIndex = 23;
            this.txtb_d_tel.Text = "无";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(54, 71);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(41, 12);
            this.label19.TabIndex = 22;
            this.label19.Text = "电话：";
            // 
            // txtb_d_contact
            // 
            this.txtb_d_contact.Location = new System.Drawing.Point(101, 41);
            this.txtb_d_contact.Name = "txtb_d_contact";
            this.txtb_d_contact.Size = new System.Drawing.Size(183, 21);
            this.txtb_d_contact.TabIndex = 21;
            this.txtb_d_contact.Text = "西门俊宇";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(42, 44);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 20;
            this.label20.Text = "联系人：";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(289, 18);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(12, 12);
            this.label21.TabIndex = 19;
            this.label21.Text = "*";
            // 
            // txtb_d_company
            // 
            this.txtb_d_company.Location = new System.Drawing.Point(101, 14);
            this.txtb_d_company.Name = "txtb_d_company";
            this.txtb_d_company.Size = new System.Drawing.Size(183, 21);
            this.txtb_d_company.TabIndex = 18;
            this.txtb_d_company.Text = "顺丰速运";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(30, 18);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 12);
            this.label22.TabIndex = 17;
            this.label22.Text = "派件公司：";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label44);
            this.tabPage3.Controls.Add(this.label43);
            this.tabPage3.Controls.Add(this.label42);
            this.tabPage3.Controls.Add(this.txtb_INSURE_value);
            this.tabPage3.Controls.Add(this.label41);
            this.tabPage3.Controls.Add(this.txtb_cod_value);
            this.tabPage3.Controls.Add(this.label40);
            this.tabPage3.Controls.Add(this.txtb_cod_custid);
            this.tabPage3.Controls.Add(this.label39);
            this.tabPage3.Controls.Add(this.checkB_COD);
            this.tabPage3.Controls.Add(this.checkB_INSURE);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(505, 410);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "增值服务";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label44.ForeColor = System.Drawing.Color.Red;
            this.label44.Location = new System.Drawing.Point(258, 132);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(12, 12);
            this.label44.TabIndex = 10;
            this.label44.Text = "*";
            this.label44.Visible = false;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label43.ForeColor = System.Drawing.Color.Red;
            this.label43.Location = new System.Drawing.Point(258, 77);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(12, 12);
            this.label43.TabIndex = 9;
            this.label43.Text = "*";
            this.label43.Visible = false;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label42.ForeColor = System.Drawing.Color.Red;
            this.label42.Location = new System.Drawing.Point(258, 50);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(12, 12);
            this.label42.TabIndex = 8;
            this.label42.Text = "*";
            this.label42.Visible = false;
            // 
            // txtb_INSURE_value
            // 
            this.txtb_INSURE_value.Location = new System.Drawing.Point(94, 129);
            this.txtb_INSURE_value.Name = "txtb_INSURE_value";
            this.txtb_INSURE_value.Size = new System.Drawing.Size(158, 21);
            this.txtb_INSURE_value.TabIndex = 7;
            this.txtb_INSURE_value.Text = "200";
            this.txtb_INSURE_value.Visible = false;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(23, 132);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(65, 12);
            this.label41.TabIndex = 6;
            this.label41.Text = "声明价值：";
            this.label41.Visible = false;
            // 
            // txtb_cod_value
            // 
            this.txtb_cod_value.Location = new System.Drawing.Point(94, 74);
            this.txtb_cod_value.Name = "txtb_cod_value";
            this.txtb_cod_value.Size = new System.Drawing.Size(158, 21);
            this.txtb_cod_value.TabIndex = 5;
            this.txtb_cod_value.Text = "2000";
            this.txtb_cod_value.Visible = false;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(23, 77);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(65, 12);
            this.label40.TabIndex = 4;
            this.label40.Text = "代收金额：";
            this.label40.Visible = false;
            // 
            // txtb_cod_custid
            // 
            this.txtb_cod_custid.Location = new System.Drawing.Point(94, 47);
            this.txtb_cod_custid.Name = "txtb_cod_custid";
            this.txtb_cod_custid.Size = new System.Drawing.Size(158, 21);
            this.txtb_cod_custid.TabIndex = 3;
            this.txtb_cod_custid.Text = "7551878519";
            this.txtb_cod_custid.Visible = false;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(23, 50);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(65, 12);
            this.label39.TabIndex = 2;
            this.label39.Text = "代收卡号：";
            this.label39.Visible = false;
            // 
            // checkB_COD
            // 
            this.checkB_COD.AutoSize = true;
            this.checkB_COD.Location = new System.Drawing.Point(23, 24);
            this.checkB_COD.Name = "checkB_COD";
            this.checkB_COD.Size = new System.Drawing.Size(72, 16);
            this.checkB_COD.TabIndex = 1;
            this.checkB_COD.Text = "代收货款";
            this.checkB_COD.UseVisualStyleBackColor = true;
            this.checkB_COD.CheckedChanged += new System.EventHandler(this.checkB_COD_CheckedChanged);
            // 
            // checkB_INSURE
            // 
            this.checkB_INSURE.AutoSize = true;
            this.checkB_INSURE.Location = new System.Drawing.Point(23, 110);
            this.checkB_INSURE.Name = "checkB_INSURE";
            this.checkB_INSURE.Size = new System.Drawing.Size(48, 16);
            this.checkB_INSURE.TabIndex = 0;
            this.checkB_INSURE.Text = "保价";
            this.checkB_INSURE.UseVisualStyleBackColor = true;
            this.checkB_INSURE.CheckedChanged += new System.EventHandler(this.checkB_INSURE_CheckedChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.txtB_Checkword);
            this.tabPage4.Controls.Add(this.txtB_JRM);
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.label1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(505, 410);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "接口信息";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(304, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 14);
            this.label4.TabIndex = 5;
            this.label4.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(304, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 14);
            this.label3.TabIndex = 4;
            this.label3.Text = "*";
            // 
            // txtB_Checkword
            // 
            this.txtB_Checkword.Location = new System.Drawing.Point(78, 125);
            this.txtB_Checkword.Name = "txtB_Checkword";
            this.txtB_Checkword.Size = new System.Drawing.Size(220, 21);
            this.txtB_Checkword.TabIndex = 3;
            this.txtB_Checkword.Text = "j8DzkIFgmlomPt0aLuwU";
            // 
            // txtB_JRM
            // 
            this.txtB_JRM.Location = new System.Drawing.Point(78, 88);
            this.txtB_JRM.Name = "txtB_JRM";
            this.txtB_JRM.Size = new System.Drawing.Size(220, 21);
            this.txtB_JRM.TabIndex = 2;
            this.txtB_JRM.Text = "BSPdevelop";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "校验码：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "接入编码：";
            // 
            // tabPage5
            // 
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(346, 410);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "其他信息";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tXTB_Request);
            this.groupBox1.Location = new System.Drawing.Point(520, 1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(429, 247);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "请求报文信息";
            // 
            // tXTB_Request
            // 
            this.tXTB_Request.Location = new System.Drawing.Point(4, 18);
            this.tXTB_Request.Multiline = true;
            this.tXTB_Request.Name = "tXTB_Request";
            this.tXTB_Request.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tXTB_Request.Size = new System.Drawing.Size(422, 223);
            this.tXTB_Request.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtb_back);
            this.groupBox2.Location = new System.Drawing.Point(520, 254);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(429, 183);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "返回报文信息";
            // 
            // txtb_back
            // 
            this.txtb_back.Location = new System.Drawing.Point(4, 18);
            this.txtb_back.Multiline = true;
            this.txtb_back.Name = "txtb_back";
            this.txtb_back.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtb_back.Size = new System.Drawing.Size(422, 157);
            this.txtb_back.TabIndex = 0;
            // 
            // lab_log
            // 
            this.lab_log.AutoSize = true;
            this.lab_log.Location = new System.Drawing.Point(3, 450);
            this.lab_log.Name = "lab_log";
            this.lab_log.Size = new System.Drawing.Size(0, 12);
            this.lab_log.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(82, 474);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 37);
            this.button2.TabIndex = 5;
            this.button2.Text = "路由查询";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label45.ForeColor = System.Drawing.Color.Red;
            this.label45.Location = new System.Drawing.Point(266, 16);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(12, 12);
            this.label45.TabIndex = 26;
            this.label45.Text = "*";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label47.ForeColor = System.Drawing.Color.Red;
            this.label47.Location = new System.Drawing.Point(266, 98);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(12, 12);
            this.label47.TabIndex = 28;
            this.label47.Text = "*";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label49.ForeColor = System.Drawing.Color.Red;
            this.label49.Location = new System.Drawing.Point(279, 69);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(12, 12);
            this.label49.TabIndex = 29;
            this.label49.Text = "*";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label50.ForeColor = System.Drawing.Color.Red;
            this.label50.Location = new System.Drawing.Point(278, 204);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(12, 12);
            this.label50.TabIndex = 30;
            this.label50.Text = "*";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label51.ForeColor = System.Drawing.Color.Red;
            this.label51.Location = new System.Drawing.Point(290, 71);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(12, 12);
            this.label51.TabIndex = 34;
            this.label51.Text = "*";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label52.ForeColor = System.Drawing.Color.Red;
            this.label52.Location = new System.Drawing.Point(290, 44);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(12, 12);
            this.label52.TabIndex = 35;
            this.label52.Text = "*";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label53.ForeColor = System.Drawing.Color.Red;
            this.label53.Location = new System.Drawing.Point(290, 206);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(12, 12);
            this.label53.TabIndex = 36;
            this.label53.Text = "*";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label54.ForeColor = System.Drawing.Color.Red;
            this.label54.Location = new System.Drawing.Point(266, 22);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(12, 12);
            this.label54.TabIndex = 29;
            this.label54.Text = "*";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 515);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lab_log);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "BSPDemoV3.2";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tXTB_Request;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtb_back;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtB_Checkword;
        private System.Windows.Forms.TextBox txtB_JRM;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox txtb_j_company;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtb_j_contact;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtb_j_address;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtb_j_county;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtb_j_city;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtb_j_province;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtb_j_mobile;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtb_j_tel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtb_d_address;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtb_d_county;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtb_d_city;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtb_d_province;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtb_d_mobile;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtb_d_tel;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtb_d_contact;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtb_d_company;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtb_orderid;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.ComboBox comb_express_type;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtb_cargo_total_weight;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtb_custid;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtb_parcel_quantity;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox comb_pay_method;
        private System.Windows.Forms.TextBox txtb_order_source;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.DateTimePicker dtp_sendstarttime;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtb_remark;
        private System.Windows.Forms.Label lab_log;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtb_CargoName;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtb_unit;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtb_count;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtb_currency;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtb_amount;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtb_weight;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtb_source_area;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.CheckBox checkB_COD;
        private System.Windows.Forms.CheckBox checkB_INSURE;
        private System.Windows.Forms.TextBox txtb_INSURE_value;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtb_cod_value;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtb_cod_custid;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label54;
    }
}

